# DH Shop & Delivery — Android APK

Application Android officielle de DH Shop & Delivery.

L'application ouvre la boutique en ligne officielle dans un WebView sécurisé et conserve le fonctionnement du site existant.

- Package : `com.dhshopdelivery.app`
- Java 17 uniquement
- Android Gradle Plugin 8.9.2
- Gradle 8.11.1
- compileSdk / targetSdk 35
- minSdk 23
