# DH Shop & Delivery — Android

Application Android officielle de DH Shop & Delivery.

L'application ouvre la boutique web officielle :
https://dhshopdelivery.github.io/dh-shop-delivery/

Configuration : Java 17 uniquement, Android SDK 36, WebView, portrait.
